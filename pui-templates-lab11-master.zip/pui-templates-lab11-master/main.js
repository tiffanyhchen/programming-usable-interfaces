// TODO (Step 2): fill in code creating products objects here
var products = {
    "cinnamonBuns": [    ]
}

$(document).ready(function(){
    // TODO (Step 4): fill in code for changing selection-template here


    // TODO (Step 7): add function call for 1st update to detail-template


    // TODO: (Step 8): add code below for changing product details on click


});

// TODO (Step 6): fill in function for updating detail-template based on id
function updateProductDetail(id) {

}
